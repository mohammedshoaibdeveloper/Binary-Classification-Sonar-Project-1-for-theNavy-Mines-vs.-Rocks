# Binary-Classification-Sonar-Project-1-for-theNavy-Mines-vs.-Rocks
In this project I have effectively use the Keras library in  machine learning project by working through a binary classification project .
## About Dataset
This is a dataset that describes sonar chirp returns bouncing off different services. The 60 input variables are the strength of the returns at different angles. It is a binary classification problem that requires a model to differentiate rocks from metal cylinders. you may find the csv file in the repostory of the project

You can learn more about this dataset on the UCI Machine Learning repository:
https://archive.ics.uci.edu/ml/datasets/Connectionist+Bench+(Sonar,+Mines+vs.+Rocks

